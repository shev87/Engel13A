#define Error_OK 0x11
#define Error_CRC 0x22
#define Error_Line 0x33
#define Error_Signature 0x44
#define Error_OverFlow 0x55
#define Error_TopModule 0x66