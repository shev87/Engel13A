This source code is intended for Microsoft Visual C++ 6.0.

A compiled version resides in 'pctools' directory.

