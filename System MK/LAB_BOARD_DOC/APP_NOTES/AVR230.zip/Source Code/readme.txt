
HOW TO GET STARTED?
===================

The easiest way to get started is to do it the first time with step-by-step
instructions. 'readme.txt' in directory 'pctools' describes how to program
an example application into AT90Mega16. With minor modifications, the same
instructions can be used for other devices as well.


