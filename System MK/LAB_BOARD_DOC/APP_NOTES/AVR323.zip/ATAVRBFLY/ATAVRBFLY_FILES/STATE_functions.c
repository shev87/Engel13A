// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : STATE_functions.c
* - Compiler          : IAR EWAAVR 4.11a
*
* - Support mail      : avr@atmel.com
*
* - Supported devices : All devices with a UART/USART can be used.
*                       The example is written for ATmega169
*
* - AppNote           : AVR323 - Interfacing GSM modems
*
* - Description       : Example of how to use AT-Commands to control a GSM modem
*
* $Revision: 1.1 $
* $Date: Tuesday, November 08, 2005 12:25:32 UTC $
*****************************************************************************/


//Includes
#include<ioavr.h>
#include<inavr.h>

#include"main.h"
#include"LCD_functions.h"

#include"..\AVRGSM_FILES\AVRGSM_api.h"
#include"..\AVRGSM_FILES\AVRGSM_com.h"
#include"..\AVRGSM_FILES\AVRGSM_tools.h"


        //Variables
static int index; //Index to read from

extern unsigned char msgbuff[161];


        //Functions
/*! \brief Init phone
 *
 *  State function
 *
 *  \param    input Dummy input...joypad value.
 *
 *  \retval   char  Next state.
 *
 */
char ST_init_phone(char input)
{
    //Local variables
    int result;

    //Initialization
    result = 0;

    result = API_modem_init();                //Setup phone

    if( result == 1 )
    {

        COM_rx_reset( );                //Reset receive buffer after API_phoneinit()
        COM_setSearchString( CMTI_ );   //Wait for "+CMTI: ,Storage,index\r\n"
        COM_rx_on( );                   //Ready to receive

        return ST_AVR_READY;
    }

    else if( result == 0 )
    {

        return ST_AVR_NO_ECHO;          //Could not set echo off
    }

    else if( result == -1 )
    {

        return ST_AVR_WRONG_STORAGE;   //No such storage locations
    }

    else
    {

        return ST_AVR_WRONG_OPTION;   //The chosen forward option is not valid for this GSM modem
    }
}


/*! \brief This function will send a user defined text string
 *
 *  State function
 *
 *  \param    input Dummy input...joypad value.
 *
 *  \retval   char  Next state.
 *
 */
char ST_send(char input)
{

    API_sendmsg("ATMEL AVR");

    return ST_AVR_READY;
}


/*! \brief This function will delete the newly arrived message
 *
 *  State function
 *
 *  \param    input Dummy input...joypad value.
 *
 *  \retval   char  Next state.
 *
 */
char ST_delete_msg( char input )
{
    API_deletemsg( index );

    index = 0;

    COM_rx_reset( );                //Reset receive buffer after API_phoneinit()
    COM_setSearchString( CMTI_ );   //Wait for "+CMTI: ,Storage,index\r\n"
    COM_rx_on( );                   //Ready to receive

    return  ST_AVR_READY;
}


/*! \brief This function extract the storage location of the newly arrived message
 *
 *  State function
 *
 *  \param    input Dummy input...joypad value.
 *
 *  \retval   char  Next state.
 *
 */
char ST_get_index( char input )
{

    index = TOOLS_decodeCMTI( );   //Find index
    return ST_AVR_NEW_SMS;
}


/*! \brief This function will read message at memory location index
 *
 *  State function
 *
 *  \param    input Dummy input...joypad value.
 *
 *  \retval   char  Next state.
 *
 */
char ST_read( char input )
{

    API_readmsg( index );           //Read new message, and decode
    LCD_puts((char *)msgbuff,1);    //Cast pointer

    COM_setSearchString( 1 );       //Set searchstring to "+CMTI: " again, wait for new message.
    COM_rx_reset( );                //Reset buffer and interrupt routine
    COM_rx_on( );                   //Ready to receive*/

    return ST_AVR_DISPLAY;
}
