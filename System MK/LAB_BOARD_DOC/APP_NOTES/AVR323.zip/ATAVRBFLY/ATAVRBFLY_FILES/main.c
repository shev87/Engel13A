// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : main.c
* - Compiler          : IAR EWAAVR 4.11a
*
* - Support mail      : avr@atmel.com
*
* - Supported devices : All devices with a UART/USART can be used.
*                       The example is written for ATmega169
*
* - AppNote           : AVR323 - Interfacing GSM modems
*
* - Description       : Example of how to use AT-Commands to control a GSM modem
*
* $Revision: 1.1 $
* $Date: Tuesday, November 08, 2005 12:25:32 UTC $
*****************************************************************************/


/*! \mainpage
 * \section Intro Introduction
 * This documents data structures, functions, variables, defines, enums, and
 * typedefs in the software for application note AVR323.\n
 *
 * \section CI Compilation Info
 * This software was written for the IAR Embedded Workbench, 4.11A.\n
 * To make project:\n
 * Add the .c files to project (main.c, AVRSMS_api.c, AVRSMS_com.c,\n
 * AVRSMS_header.h, AVRSMS_tools.c and AVRSMS_zip.c). Use device
 * --cpu=m169, enable bit definitions in I/O include files, optimization low
 * for debug target and high for release, output format: ubrof8 for Debug and
 * intel_extended for Release \n
 *
 * Set the correct receivers phone number in "AVRGSM_header.h".\n
 * The dummy +4712345678 will not work!\n
 *
 * \section DI Device Info
 * Devices with a UART/USART can be used. The example is
 * written for ATmega169.\n
 *
 * \section TDL ToDo List
 * Add suport for GPRS.\n
 */


//Includes
#include<inavr.h>
#include<iom169.h>

#include"main.h"
#include"LCD_functions.h"
#include"LCD_driver.h"
#include"button.h"
#include"BCD.h"
#include"types.h"
#include"STATE_functions.h"
#include"menu.h"

#include"..\AVRGSM_FILES\AVRGSM_api.h"
#include"..\AVRGSM_FILES\AVRGSM_com.h"


#define pLCDREG_test (*(char *)(0xEC))


extern int rx_ack; //From AVRGSM_com.c

extern __flash unsigned int LCD_character_table[];

unsigned char state;            // helds the current state, according to
                                // "menu.h"


/*! \brief This function is the main loop.
 *
 *  The main loop control a state machine, and reacts on joypad stimuli or arrival\n
 *  of new messages.
 *
 *  \param    void
 *
 *  \retval   none
 */
__C_task void main( void )
{

    //! Local variables
    unsigned char nextstate;
    static char __flash *statetext;
    char (*pStateFunc)(char);
    char input;
    char i;

    //! Initialization of state variables
    state = nextstate = ST_AVR_IDLE;
    statetext = MT_IDLE;
    pStateFunc = NULL;


    //! Program initalization
    Initialization( );
    __enable_interrupt();


   //! DO this forever
    for( ;; )
    {

        if( ( state == ST_AVR_READY ) && ( rx_ack == 1 ) )      //New SMS
        {

            state = nextstate = ST_AVR_NEW_SMS_function;     //Setting new state
            statetext = NULL;
            pStateFunc = ST_get_index;
        }

        // Plain menu text
        if( statetext )
        {

            LCD_puts_f( statetext, 1 );
            LCD_Colon( 0 );
            statetext = NULL;
        }

        //Get input
        input = getkey( );

        if ( pStateFunc )
        {

            // When in this state, we must call the state function
            nextstate = pStateFunc(input);
        }

        else if (input != KEY_NULL)
        {

            // Plain menu, clock the state machine
            nextstate = StateMachine(state, input);
        }

        if (nextstate != state)
        {
            state = nextstate;

            for (i=0; menu_state[i].state; i++)
            {

                if (menu_state[i].state == state)
                {

                    statetext =  menu_state[i].pText;
                    pStateFunc = menu_state[i].pFunc;
                    break;
                }
            }
        }
    }
}


/*! \brief This function controls the state machine.
 *
 *
 *  \param    state     Present state
 *  \param    stimuli   Input from joypad
 *
 *  \retval   nextstate New state of the system
 */
unsigned char StateMachine( char state, unsigned char stimuli )
{

    unsigned char nextstate = state;    // Default stay in same state
    unsigned char i;

    for ( i=0; menu_nextstate[i].state; i++ )
    {

        if ( ( menu_nextstate[i].state == state ) && ( menu_nextstate[i].input == stimuli ) )
        {

            // This is the one!
            nextstate = menu_nextstate[i].nextstate;
            break;
        }
    }

    return nextstate;
}


/*! \brief This function setup the hardware.
 *
 *  Set up:\n
 *   *PORTB\n
 *   *PORTE\n
 *   *Serial communication\n
 *   *Buttons\n
 *   *LCD
 *
 *  \param    void
 *
 *  \retval   none
 */
void Initialization(void)
{

    PORTB = (15<<PORTB0);   // Enable pullup on
    PORTE = (15<<PORTE4);

    COM_init( 51 );         //9600bps @ 8MHz
    Button_Init( );         // Initialize pin change interrupt on joystick
    LCD_Init( );            // initialize the LCD
}
