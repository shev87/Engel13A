// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation
*
* - File              : button.h
* - Compiler          : IAR EWAAVR 4.11a
*
* - Support mail      : avr@atmel.com
*
* - Supported devices : All devices with a UART/USART can be used.
*                       The example is written for ATmega169
*
* - AppNote           : AVR323 - Interfacing GSM modems
*
* - Description       : Example of how to use AT-Commands to control a GSM modem
*
* $Revision: 1.1 $
* $Date: Tuesday, November 08, 2005 12:25:32 UTC $
*****************************************************************************/

#ifndef BUTTON_H_INCLUDED
#define BUTTON_H_INCLUDED


    #define PINB_MASK ((1<<PINB4)|(1<<PINB6)|(1<<PINB7))
    #define PINE_MASK ((1<<PINE2)|(1<<PINE3))

    #define BUTTON_A    6   // UP
    #define BUTTON_B    7   // DOWN
    #define BUTTON_C    2   // LEFT
    #define BUTTON_D    3   // RIGHT
    #define BUTTON_O    4   // PUSH

    void PinChangeInterrupt(void);
    void Button_Init(void);
    char getkey(void);
    char ButtonBouncing(void);

#endif
