/****************************************************************************
 **             - iotiny13.h -
 **
 **     This file declares the internal register addresses for ATtiny13.
 **
 **     Used with iccAVR and aAVR.
 **
 **     Copyright IAR Systems 2002. All rights reserved.
 **	Modified by RAA, Atmel Norway, 2003
 **
 **     $Name: $
 **
 ***************************************************************************/

#include "iomacro.h"

#if TID_GUARD(0)
#error This file should only be compiled with iccavr or aavr whith processor option -v0
#endif /* TID_GUARD(0) */

/* Include the SFR part if this file has not been included before,
 * OR this file is included by the assembler (SFRs must be defined in
 * each assembler module). */
#if !defined(__IOTINY13_H) || defined(__IAR_SYSTEMS_ASM__)

#pragma language=extended

/*==========================*/
/* Predefined SFR Addresses */
/*==========================*/

/****************************************************************************
 * An example showing the SFR_B() macro call, 
 * the expanded result and usage of this result:
 *
 * SFR_B(AVR,   0x1F) Expands to:
 * __io union {
 *             unsigned char AVR;                 // The sfrb as 1 byte
 *             struct {                           // The sfrb as 8 bits
 *                     unsigned char AVR_Bit0:1,
 *                                   AVR_Bit1:1,
 *                                   AVR_Bit2:1,
 *                                   AVR_Bit3:1,
 *                                   AVR_Bit4:1,
 *                                   AVR_Bit5:1,
 *                                   AVR_Bit6:1,
 *                                   AVR_Bit7:1;
 *                    };
 *            } @ 0x1F;
 * Examples of how to use the expanded result:
 * AVR |= (1<<5);
 * or like this:
 * AVR_Bit5 = 1;
 ***************************************************************************/

SFR_B(ADCSRB, 0x03) /* ADC Control and Status Register B */
SFR_W(ADC,    0x04) /* ADC Data Register */
SFR_B(ADCSRA, 0x06) /* ADC Control and Status Register A */
SFR_B(ADMUX,  0x07) /* ADC Multiplexer Select Register */
SFR_B(ACSR,   0x08) /* Analog Comparator Control and Status Register */
SFR_B(DIDR0,  0x14) /* Digital Input Disable Register */
SFR_B(PCMSK,  0x15) /* PC Interrupt Mask Register */
SFR_B(PINB,   0x16) /* Input Pins, Port B */
SFR_B(DDRB,   0x17) /* Data Direction Register, Port B */
SFR_B(PORTB,  0x18) /* Data Register, Port B */
SFR_B(EECR,   0x1C) /* EEPROM Control Register */
SFR_B(EEDR,   0x1D) /* EEPROM Data Register */
SFR_B(EEAR,   0x1E) /* EEPROM Address Register */
SFR_B(WDTCR,  0x21) /* Watchdog Timer Control Register */
SFR_B(CLKPR,  0x26) /* Clock Prescaler Register */
SFR_B(GTCCR,  0x28) /* General Timer/Counter Control Register */
SFR_B(OCR0B,  0x29) /* Timer/Counter0 Output Compare Register B */
SFR_B(DWDR,   0x2E) /* debugWire Data Register */
SFR_B(TCCR0A, 0x2F) /* Timer/Counter0 Control Register A */
SFR_B(OSCCAL, 0x31) /* Oscillator Calibration Register */
SFR_B(TCNT0,  0x32) /* Timer/Counter0 */
SFR_B(TCCR0B, 0x33) /* Timer/Counter0 Control Register B */
SFR_B(MCUSR,  0x34) /* MCU Status Register */
SFR_B(MCUCR,  0x35) /* MCU Control Register */
SFR_B(OCR0A,  0x36) /* Timer/Counter0 Output Compare Register A */
SFR_B(SPMCSR, 0x37) /* SPM Control and Status Register */
SFR_B(TIFR0,  0x38) /* Timer/Counter0 Interrupt Flag Register */
SFR_B(TIMSK0, 0x39) /* Timer/Counter0 Interrupt Mask Register */
SFR_B(GIFR,   0x3A) /* General Interrupt Flag Register */
SFR_B(GIMSK,  0x3B) /* General Interrupt Mask Register */
SFR_B(SPL,    0x3D) /* Stack Pointer Low */
SFR_B(SREG,   0x3F) /* Status Register */

#ifndef __IOTINY13_H
#define __IOTINY13_H

/* SFRs are local in assembler modules (so this file may need to be */
/* included in more than one module in the same source file), */
/* but #defines must only be made once per source file. */

/*==============================*/
/* Interrupt Vector Definitions */
/*==============================*/

/* NB! vectors are specified as byte addresses */

#define RESET_vect        (0x00)
#define INT0_vect         (0x02)
#define PCINT0_vect       (0x04)
#define TIMER0_OVF0_vect  (0x06)
#define EE_RDY_vect       (0x08)
#define ANA_COMP_vect     (0x0A)
#define TIMER0_CMPA_vect  (0x0C)
#define TIMER0_CMPB_vect  (0x0E)
#define WDT_vect          (0x10)
#define ADC_vect          (0x12)


#ifdef __IAR_SYSTEMS_ASM__   
#ifndef ENABLE_BIT_DEFINITIONS
#define  ENABLE_BIT_DEFINITIONS
#endif /* ENABLE_BIT_DEFINITIONS */
#endif /* __IAR_SYSTEMS_ASM__ */

#ifdef ENABLE_BIT_DEFINITIONS
 
/* Bit definitions for use with the IAR Assembler   
   The Register Bit names are represented by their bit number (0-7). */     

/* ADC Control and Status Register B - ADCSRB */
#define    ACME     6
#define    ADTS2    2
#define    ADTS1    1
#define    ADTS0    0

/* ADC Control and Status Register A - ADCSRA */  
#define    ADEN     7
#define    ADSC     6
#define    ADATE    5
#define    ADIF     4
#define    ADIE     3
#define    ADPS2    2
#define    ADPS1    1
#define    ADPS0    0

/* ADC Multiplexer Selection Register - ADMUX */  
#define    REFS0    6
#define    ADLAR    5
#define    MUX1     1
#define    MUX0     0

/* Analog Comparator Control And Status Register - ACSR */  
#define    ACD      7
#define    ACBG     6
#define    ACO      5
#define    ACI      4
#define    ACIE     3
#define    ACIS1    1
#define    ACIS0    0

/* Digital Input Disable Register 0 - DIDR0 */
#define    ADC0D    5
#define    ADC2D    4
#define    ADC3D    3
#define    ADC1D    2
#define    AIN1D    1
#define    AIN0D    0

/* PC Interrupt Mask Register - PCMSK */
#define    PCINT5   5
#define    PCINT4   4
#define    PCINT3   3
#define    PCINT2   2
#define    PCINT1   1
#define    PCINT0   0

/* Port B Input Pins Address - PINB */
#define    PINB5    5
#define    PINB4    4
#define    PINB3    3
#define    PINB2    2
#define    PINB1    1
#define    PINB0    0

/* Port B Data Direction Register - DDRB */
#define    DDB5     5
#define    DDB4     4
#define    DDB3     3
#define    DDB2     2
#define    DDB1     1
#define    DDB0     0

/* Port B Data Register - PORTB */
#define    PB5      5
#define    PB4      4
#define    PB3      3
#define    PB2      2
#define    PB1      1
#define    PB0      0

/* Port B Data Register - PORTB */
#define    PORTB5   5
#define    PORTB4   4
#define    PORTB3   3
#define    PORTB2   2
#define    PORTB1   1
#define    PORTB0   0

/* EEPROM Control Register - EECR */
#define    EEPM1    5
#define    EEPM0    4
#define    EERIE    3
#define    EEMWE    2
#define    EEWE     1
#define    EERE     0

/* EEPROM Address Register - EEAR */
#define    EEAR6    6
#define    EEAR5    5
#define    EEAR4    4
#define    EEAR3    3
#define    EEAR2    2
#define    EEAR1    1
#define    EEAR0    0

/* Watchdog Timer Control Register - WDTCR */
#define    WDTIF    7
#define    WDTIE    6
#define    WDP3     5
#define    WDCE     4
#define    WDE      3
#define    WDP2     2
#define    WDP1     1
#define    WDP0     0

/* Clock Prescaler Register - CLKPR */
#define    CLKPCE   7
#define    CLKPS3   3
#define    CLKPS2   2
#define    CLKPS1   1
#define    CLKPS0   0

/* General Timer/Counter Control Register - GTCCR */
#define    TSM      7
#define    PSR10    0

/* Timer/Counter0 Control Register A - TCCR0A */
#define    COM0A1   7
#define    COM0A0   6
#define    COM0B1   5
#define    COM0B0   4
#define    WGM01    1
#define    WGM00    0

/* Timer/Counter0 Control Register B - TCCR0B */
#define    FOC0A    7
#define    FOC0B    6
#define    WGM02    3
#define    CS02     2
#define    CS01     1
#define    CS00     0

/* MCU Status Register - MCUSR */ 
#define    WDRF     3
#define    BORF     2
#define    EXTRF    1
#define    PORF     0
 
/* MCU Control Register - MCUCR */ 
#define    PUD      6
#define    SE       5
#define    SM1      4
#define    SM0      3
#define    ISC01    1
#define    ISC00    0

/* SPM Control and Status Register */
#define    CTPB     4
#define    RFLB     3
#define    PGWRT    2
#define    PGERS    1
#define    SPMEN    0

/* Timer/Counter0 Interrupt Flag Register - TIFR0 */                   
#define    OCF0B    3
#define    OCF0A    2
#define    TOV0     1

/* Timer/Counter0 Interrupt Mask register - TIMSK0 */                 
#define    OCIE0B   3
#define    OCIE0A   2
#define    TOIE0    1

/* General Interrupt Flag Register - GIFR */
#define    INTF0    6
#define    PCIF     5
 
/* General Interrupt Mask register - GIMSK */
#define    INT0     6
#define    PCIE     5
 
/* Stack Pointer - SP */
#define    SP7      7
#define    SP6      6
#define    SP5      5
#define    SP4      4
#define    SP3      3
#define    SP2      2
#define    SP1      1
#define    SP0      0

/* Pointer definition   */ 
#define    XL     R26
#define    XH     R27
#define    YL     R28
#define    YH     R29
#define    ZL     R30
#define    ZH     R31
       
/* Contants */ 
#define    RAMEND    0x9F    /* Last On-Chip SRAM Location */
#define    XRAMEND   0x9F
#define    E2END     0x3F
#define    FLASHEND  0x03FF

#endif /* ENABLE_BIT_DEFINITIONS */
#endif /* __IOTINY13_H (define part) */

#pragma language=default

#endif /* __IOTINY13_H (SFR part) */
