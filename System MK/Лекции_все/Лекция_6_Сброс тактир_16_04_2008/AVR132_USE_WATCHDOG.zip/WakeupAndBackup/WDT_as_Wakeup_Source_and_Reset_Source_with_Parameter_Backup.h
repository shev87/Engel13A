/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : WDT_as_Wakeup_Source_and_Reset_Source_with_Parameter_Backup.h
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 20.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Application note  : AVR132 Using the Enhanced Watchdog Timer
* Description       : Initialization routines for setting up the Enhanced Watchdog
*                     Timer as a Wakeup source and a Watchdog System Reset and with backup
*                     of parameters prior to the Reset.
*
****************************************************************************/

//********** Defines **********//


//********** Prototypes **********//

unsigned char WDT_Initialization_as_Wakeup_and_Reset_Source_w_Backup( void );
