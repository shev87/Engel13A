/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : WDT_as_Wakeup_Source_and_Reset_Source_with_Parameter_Backup.c
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 20.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Application note  : AVR132 Using the Enhanced Watchdog Timer
* Description       : Initialization routines for setting up the Enhanced Watchdog
*                     Timer as a Wakeup source and a Watchdog System Reset and with backup
*                     of parameters prior to the Reset.
*
* When in sleep mode, the Enhanced Watchdog Timer is used for waking up the CPU.
* When in Active mode, the Enhanced Watchdog Timer is used for backing up vital
* parameters prior to Watchdog System Reset.
*
* In this example, the Timer/Counter0 value is backed up. The Timer/Counter0 is 
* never used in the application, but serves as an example for parameter backup only.
*
****************************************************************************/

#include <inavr.h>
#include <iotiny13.h>
#include "WDT_as_Wakeup_Source_and_Reset_Source_with_Parameter_Backup.h"

#define TRUE                      1
#define FALSE                     0
#define OK                        1
#define FAIL                      0

/* Variable in non-volatile memory for counting Watchdog Resets */
unsigned char __eeprom wdr_count = 0;                   // Initialize to 0 on first programming.
#define WDR_LIMIT                 3                     // Watchdog System Reset count cannot exceed this limit.

/* Parameter backup in non-volatile memory */
unsigned char __eeprom wdr_backup_write_complete = 0;   // Write Complete flag.
unsigned char __eeprom wdr_backup_parameter;            // Parameter value, a byte in this example.


/* Watchdog Timer Interrupt Handler */
#pragma vector = WDT_vect
__interrupt void WDT_Timeout_ISR( void )
{
    // The first block in the following if-construct can be omitted if the wakeup functionality is not needed

    /* Use the Sleep Enable bit as a flag for indicating wakeup or parameter backup */
    if( MCUCR & (1<<SE) )
    {
        MCUCR &= ~(1<<SE);                  // Clear Sleep Enable on wakeup.

        // The Watchdog Interrupt Mode must be re-enabled outside the interrupt handler to ensure
        // that the parameter backup code is executed prior to a Watchdog System Reset.
    }
    else
    {
        /* Backup all your parameters here. */
        wdr_backup_parameter = TCNT0;       // For demonstration purposes we here backup the Timer/Counter0 value.
    
        /* Set Write Complete flag to indicate backup successful */
        wdr_backup_write_complete = 1;
    
        /* Infinite loop waiting for next timeout to cause a Watchdog System Reset */
        for(;;);
    }
}


/* Initialization routine */
unsigned char WDT_Initialization_as_Wakeup_and_Reset_Source_w_Backup( void )
{
    unsigned char reset_flags;
    
    /* Read and clear reset flags */
    reset_flags = MCUSR;                    // Save reset flags.
    MCUSR = 0;                              // Clear all flags previously set.

    /* Setup Watchdog */
    WDTCR   =   (1<<WDTIF)|(1<<WDTIE)|                     // Enable Watchdog Interrupt Mode.
                (1<<WDCE )|(1<<WDE  )|                     // Set Change Enable bit and Enable Watchdog System Reset Mode.
                (1<<WDP3 )|(0<<WDP2 )|(0<<WDP1)|(0<<WDP0); // Set Watchdog Timeout period to 4.0 sec.

    /* If no reset flags are set, runaway code wrapped back to address 0 */
    if( reset_flags == 0 )
    {
        __disable_interrupt();
        for(;;);                            // Let the Watchdog time out and cause a Watchdog System Reset.
    }

    /* Check for Watchdog System Reset */
    if( reset_flags & (1<<WDRF) )
    {
        wdr_count++;                        // Increase Watchdog System Reset counter.
        
        /* Restore backed up parameter if valid */
        if( wdr_backup_write_complete == 1 )
        {                                   // Restore all your parameters here.
            TCNT0 = wdr_backup_parameter;   // For demonstration purposes we here restore the Timer/Counter0 value.
            wdr_backup_write_complete = 0;  // Backed up parameter is now invalid.
        } else
        {
            // If we arrive here, a Watchdog System Reset has occured, but the Watchdog Interrupt was never executed
            // or never finished backing up vital parameters. Insert code here to take care of this special case.
            // There was probably some part of the code that disabled global interrupts or disabled Watchdog Interrupt Mode.
        }
        
        /* Has the number of subsequent WDT Resets exceeded its max limits? */
        if( wdr_count >= WDR_LIMIT )
        {
            return FAIL;                    // Return the error message.
        }
    }
    
    /* Clear the Watchdog System Reset Counter on power-up or external reset */
    if( reset_flags & (1<<PORF) || reset_flags & (1<<EXTRF) )
    {
        wdr_count = 0;
    }

    return OK;                             
}
