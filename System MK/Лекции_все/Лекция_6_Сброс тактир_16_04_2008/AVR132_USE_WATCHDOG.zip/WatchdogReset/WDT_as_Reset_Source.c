/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : WDT_as_Reset_Source.c
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 20.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Application note  : AVR132 Using the Enhanced Watchdog Timer
* Description       : Initialization routines for setting up the Enhanced 
*                     Watchdog Timer as a System Reset Source
*
*
****************************************************************************/
    
#include <inavr.h>
#include <iotiny13.h>
#include "WDT_as_Reset_Source.h"

#define TRUE                      1
#define FALSE                     0
#define OK                        1
#define FAIL                      0

/* Variable in non-volatile memory for counting Watchdog System Resets */
unsigned char __eeprom wdr_count = 0;   // Initialize to 0 on first programming.
#define WDR_LIMIT                 3     // Watchdog System Reset count cannot exceed this limit.


/* Initialization routine */
unsigned char WDT_Initialization_as_Reset_Source( void )
{
    unsigned char reset_flags;
    
    /* Read and clear reset flags */
    reset_flags = MCUSR;                // Save reset flags.
    MCUSR       = 0;                    // Clear all flags previously set.

    /* Setup Watchdog */
    WDTCR   =   (1<<WDTIF)|(0<<WDTIE)|(1<<WDCE)|(1<<WDE )| // Set Change Enable bit and Enable Watchdog System Reset Mode.
                (1<<WDP3 )|(0<<WDP2 )|(0<<WDP1)|(0<<WDP0); // Set Watchdog timeout period to 4.0 sec.
    
    /* If no reset flags are set, runaway code wrapped back to address 0 */
    if( reset_flags == 0 )
    {
        __disable_interrupt();
        for(;;);                        // Let the Watchdog time out and cause a Watchdog System Reset.
    }

    /* Check for Watchdog System Reset */
    if( reset_flags & (1<<WDRF) )
    {
        wdr_count++;                    // Increase Watchdog System Reset counter.
        
    /* Has the number of subsequent Watchdog System Resets exceeded its max limits? */
        if( wdr_count >= WDR_LIMIT )
        {
            return FAIL;               // Report back an error message.
        }
    }
    
    /* Clear the Watchdog System Reset Counter on power-up or external reset */
    if( reset_flags & (1<<PORF) || reset_flags & (1<<EXTRF) )
    {
        wdr_count = 0;
    }
    
    return OK;                        
}
