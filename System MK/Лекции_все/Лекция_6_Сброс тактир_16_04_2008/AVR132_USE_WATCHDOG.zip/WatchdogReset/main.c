/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : main.c
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 20.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Application note  : AVR132 Using the Enhanced Watchdog Timer
* Description       : Application example using the Enhanced Watchdog Timer as
*                     a Watchdog System Reset source
*
*
*
****************************************************************************/
    
#include <inavr.h>
#include <iotiny13.h>
#include "WDT_as_Reset_Source.h"

/* Define PORTB pin functions */
#define READY_LED    PB0
#define FAILURE_LED  PB1
#define COMMAND1     PB2
#define COMMAND2     PB3
#define COMMAND3     PB4

#define TRUE         1
#define FALSE        0
#define OK           1
#define FAIL         0

/* Global health flags */
struct
{
    unsigned char communication_ok : 1;
    unsigned char parser_ok        : 1;
    unsigned char executed_ok      : 1;
} health_flags;


/* EEPROM Ready Interrupt Handler */
#pragma vector = EE_RDY_vect
__interrupt void EEPROM_Ready_ISR( void )
{
    __delay_cycles( 10 );               // No useful code here, since this is just an example on
                                        // repeated interrupts slowing down the main loop.
}

/* Communication routine to read command button status */
unsigned char Communicate( void )
{
    unsigned char i;
    unsigned bits;

    /* Flash ready LED 10 times to ask for command input */
    for( i = 0; i < 10; i++ )
    {
        __delay_cycles( 32768 );
        PORTB |= (1<<READY_LED);
        __delay_cycles( 32768 );
        PORTB &= ~(1<<READY_LED);
    }
    
    /* Wait for command */
    while( !(~PINB & ( (1<<COMMAND1) | (1<<COMMAND2) | (1<<COMMAND3) ) ) )
        ; // Do nothing while waiting, causing a Watchdog Reset if left waiting too long

    bits = ~PINB & ( (1<<COMMAND1) | (1<<COMMAND2) | (1<<COMMAND3) ); // Save command bits

    /* Turn off ready LED */
    PORTB |= (1<<READY_LED);

    /* Wait a while with ready LED off to incicate that command has been received */
    for( i = 0; i < 10; i++ )
    {
        __delay_cycles( 32768 );
    }
    
    /* Indicate good health for communication routine */
    health_flags.communication_ok = 1;
    
    /* Return command */
    return bits;
}


/* Convert command from input pins to command code */
unsigned char Parse( unsigned char bits )
{
    unsigned char code;

    /* Compare against command bit values */
    switch( bits )
    {
        case (1<<COMMAND1) :
            code = 1;
            health_flags.parser_ok = 1; // Indicate good health
            break;
            
        case (1<<COMMAND2) :
            code = 2;
            health_flags.parser_ok = 1; // Indicate good health
            break;
            
        case (1<<COMMAND3) :
            code = 3;
            health_flags.parser_ok = 1; // Indicate good health
            break;
            
        // Note that combined commands are never checked. Therefore the health flag
        // for the parser will not be set if more than one command button is pressed.
    }
    
    /* Return command code back to caller */
    return code;
}
            


/* Execute supported commands */
void Execute( unsigned char command )
{
    switch( command )
    {
        // Command 1 does nothing useful in this example
            
        /* Command 2 */
        case 2 :
            EECR |= (1<<EERIE);     // Enable EEPROM ready interrupt, causing
            break;                  // repeated interrupts slowing down the main loop.
    
        /* Command 3 */
        case 3 :
            ((void (*)()) 0x1FF)(); // Call unused flash, causing runaway execution.
            break;
    }
    
    /* Indicate good health for execution routine */
    health_flags.executed_ok = 1;
}


/* Check all health flags and reset Watchdog if ok */
void Check_Health( void )
{
    if( health_flags.communication_ok &&
        health_flags.parser_ok        &&
        health_flags.executed_ok        )
    {
        /* Clear all health flags */
        health_flags.communication_ok = 0;
        health_flags.parser_ok        = 0;
        health_flags.executed_ok      = 0;
    
        /* Reset Watchdog */
        __watchdog_reset();
    }
}


/* Main loop */
__C_task void main( void )
{
    unsigned char command;
    
    /* Initialize PORTB to show status information on LEDs */
    PORTB = 0xFF;                               // Set outputs to high and enable pullups on input lines.
    DDRB  = (1<<READY_LED) | (1<<FAILURE_LED);  // Set LED pins to output.

    /* Perform system initialization */
    if( WDT_Initialization_as_Reset_Source() == FAIL)
    {
        PORTB &= ~(1<<FAILURE_LED);             // Turn on failure indicator.
        for(;;)                                 // Inifinite loop.
        {
            __watchdog_reset();
        }
    }
  
    __enable_interrupt();
    
    /* Reset Watchdog Timer and enter main loop */
    __watchdog_reset();
    
    for(;;)
    {
        /* Get, parse and execute command */
        command = Communicate();
        command = Parse( command );
        Execute( command );

        /* Perform health check before repeating main loop */
        Check_Health();
    }
}
