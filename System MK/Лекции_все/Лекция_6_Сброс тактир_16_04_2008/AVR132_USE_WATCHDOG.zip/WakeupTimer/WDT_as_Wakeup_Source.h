/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : WDT_as_Wakeup_Source.h
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 20.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Application note  : AVR132 Using the Enhanced Watchdog Timer
* Description       : Header file for using the Enhanced Watchdog Timer as 
*                     a Wakeup source from Power-down Sleep Mode.
*
*
****************************************************************************/

//********** Defines **********//


//********** Prototypes **********//

void WDT_Initialization_as_Wakeup_Source( void );
