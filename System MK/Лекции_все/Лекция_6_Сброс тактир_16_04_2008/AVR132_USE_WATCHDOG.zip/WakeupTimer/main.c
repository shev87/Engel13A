/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : main.c
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 22.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Description       : Application example using the Enhanced Watchdog Timer 
*                     as a Wakeup source from Power-down Sleep Mode.
*
*
****************************************************************************/
    
#include <inavr.h>
#include <iotiny13.h>
#include "WDT_as_Wakeup_Source.h"

/* Define PORTB pin functions */
#define STATUS_LED    PB0

/* Main loop */
__C_task void main( void )
{
    unsigned char i;

    /* Perform system initialization */
    WDT_Initialization_as_Wakeup_Source();

    /* Enable interrupts */
    __enable_interrupt();

    /* Initialize PORTB */
    PORTB  = 0xFF;                      // Set outputs to high and enable pullups on input lines
    DDRB   = (1<<STATUS_LED);           // Set LED pin to output

    /* Enter main loop */
    for(;;)
    {
        /* Flash status LED */
        for( i = 0; i < 10; i++ )
        {
            PORTB &= ~(1<<STATUS_LED);  // Turn on LED
            __delay_cycles( 32768 );
            
            PORTB |=  (1<<STATUS_LED);  // Turn off LED
            __delay_cycles( 32768 );
        }

        /* Sleep for one Watchdog Timer period */
        __watchdog_reset();     // Reset Wathdog Timer to ensure sleep for one whole Watchdog Timer period
        WDTCR |= (1<<WDTIE);    // Enable Watchdog Interrupt Mode
        __sleep();
    }
}
