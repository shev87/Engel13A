/*****************************************************************************
*
* Copyright (C) 2003 Atmel Corporation
*
* File              : WDT_as_Wakeup_Source.c
* Compiler          : IAR EWAAVR 2.28a
* Created           : 01.08.2003 by RAA
* Modified          : 22.08.2003 by LTA
* Modified          : 01.10.2003 by RAA
*
* Support mail      : avr@atmel.com
*
* Supported devices : ATtiny13
*
* Description       : Initialization routines for setting up the Enhanced Watchdog Timer 
*                     as a Wakeup source from Power-down Sleep Mode.
*
*
****************************************************************************/
    
#include <inavr.h>
#include <iotiny13.h>
#include "WDT_as_Wakeup_Source.h"

/* Watchdog Interrupt Handler */
#pragma vector = WDT_vect
__interrupt void WDT_Timeout_ISR( void )
{
    WDTCR &= ~(1<<WDTIE);               // Disable Watchdog Interrupt Mode
                                        // This can be omitted if repeated interrups are needed
}

/* Initialization routine */
void WDT_Initialization_as_Wakeup_Source( void )
{    
    /* Setup Watchdog */      
    // Use Timed Sequence for disabling Watchdog System Reset Mode if it has been enabled unintentionally.
    MCUSR  &=  ~(1<<WDRF);                                 // Clear WDRF if it has been unintentionally set.
    WDTCR   =   (1<<WDCE )|(1<<WDE  );                     // Enable configuration change.
    WDTCR   =   (1<<WDTIF)|(1<<WDTIE)|                     // Enable Watchdog Interrupt Mode.
                (1<<WDCE )|(0<<WDE  )|                     // Disable Watchdog System Reset Mode if unintentionally enabled.
                (1<<WDP3 )|(0<<WDP2 )|(0<<WDP1)|(0<<WDP0); // Set Watchdog Timeout period to 4.0 sec.

    /* Enable Power Down Sleep Mode */
    MCUCR |= (1<<SM1) | (1<<SE);
}
